# SYSTEM OF KIRA — Android Studio Project

Native Kotlin + Jetpack Compose dark anime-inspired leveling app. Original vector shadow-warrior art is included locally; no network access is required at runtime.

## Part 3 RPG systems
- Persistent Shadow Army roster with rarity, levels, evolution, abilities and commander hierarchy.
- Training consumes materials; evolution requires level 10 and 3 materials.
- Gear inventory with rarity, slot-specific equipment, upgrades and material crafting.
- Skill tree with unlockable active attacks and passive combat bonuses.
- Three dungeon routes, standard and elite encounters, a two-phase boss, turn-based combat, victory/defeat states, and locally persisted battle state.
- Fictional battle rewards, materials, victory count and XP history are separate from real-life study/workout logging.
- Weekly reports for study minutes, workout minutes, quests, gate wins and XP history, plus E–S rank achievement milestones.
- Room migration from database version 1 to 2 preserves existing quest, player and activity data while adding the game-save table.

## Existing personal progression
- Daily, weekly and custom quests, exactly-once completion rewards per applicable period.
- Study and workout logs, player XP/level, settings and offline persistence.

## Architecture
- `data/Entities.kt`: Room entities for personal progression.
- `data/KiraDatabase.kt`: Room DAO/database and non-destructive v1→v2 migration.
- `data/KiraRepository.kt`: quest and real-life activity rules.
- `data/GameProgress.kt`: RPG state model, local save codec, and transactional game repository.
- `KiraViewModel.kt`: screen state and actions.
- `MainActivity.kt`: connected Compose navigation and screens.

## Open and build
Open this folder in Android Studio, allow Gradle sync, then run the `app` configuration on an Android 8.0+ device or emulator. The project targets SDK 35 and Java 17 bytecode.

Build a debug APK with Android Studio **Build → Build APK(s)** or, if the Gradle wrapper is available, `./gradlew assembleDebug`. The expected output is `app/build/outputs/apk/debug/app-debug.apk`.

## Limitations
This environment does not currently have an Android SDK or Gradle executable available, so APK compilation and on-device testing cannot be verified here. Combat is a deterministic turn-based prototype, not a real-time action engine. No paid loot boxes, network calls, or real-world combat mechanics are included.


## Tests and verification

- Local JVM tests: `./gradlew testDebugUnitTest` (or Android Studio: app > Tasks > verification > testDebugUnitTest).
- Instrumented Room tests: `./gradlew connectedDebugAndroidTest` with an emulator/device running.
- `ProgressionRulesTest` covers XP carry-over, lifetime XP, E–S rank thresholds, and custom quest one-time periods.
- `KiraRepositoryTest` covers duplicate custom-quest rewards and player/quest persistence after closing and reopening the Room database.
- In this delivery environment, a standalone Kotlin smoke harness compiled and ran against `ProgressionRules.kt`; it verified XP carry-over, all six rank thresholds, and custom completion period. The Android Gradle build and Room instrumentation tests could not be run because Android SDK/Gradle are unavailable and network DNS is blocked. Do not treat those Android tests as passed until executed in Android Studio.

## Build prerequisites

Install Android Studio with Android SDK Platform 35 and Build Tools, and use JDK 17 or newer. The Android Gradle Plugin 8.7.3 build uses Gradle 8.9. Open the project root (`system-of-kira`) in Android Studio and let Gradle sync/download dependencies. To create a debug APK choose **Build → Build APK(s)**; expected output: `app/build/outputs/apk/debug/app-debug.apk`. To run the Room tests, launch an emulator and run the `connectedDebugAndroidTest` Gradle task.
