package com.kira.system.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class KiraRepositoryTest {
    private lateinit var context: Context
    private lateinit var db: KiraDatabase
    private lateinit var repository: KiraRepository
    private val dbName = "kira-repository-test.db"

    @Before fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.deleteDatabase(dbName)
        db = Room.databaseBuilder(context, KiraDatabase::class.java, dbName).allowMainThreadQueries().build()
        repository = KiraRepository(db)
    }

    @After fun tearDown() {
        db.close()
        context.deleteDatabase(dbName)
    }

    @Test fun customQuestAwardsXpOnlyOnce() = runBlocking {
        repository.initialize()
        repository.createQuest("TEST QUEST", "Test duplicate prevention", "STUDY", "CUSTOM", 75)
        // Resolve the just-created row directly by its unique test title.
        val id = db.query("SELECT id FROM quests WHERE title = 'TEST QUEST' LIMIT 1", null).use { cursor ->
            assertTrue(cursor.moveToFirst()); cursor.getString(0)
        }
        val first = repository.completeQuest(id)
        val second = repository.completeQuest(id)
        assertTrue(first.accepted)
        assertEquals(75, first.xp)
        assertFalse(second.accepted)
        assertEquals(0, second.xp)
        assertEquals(75L, db.dao().getPlayer()!!.totalXp)
    }

    @Test fun playerAndQuestCompletionSurviveDatabaseReopen() = runBlocking {
        repository.initialize()
        repository.createQuest("PERSIST ME", "Persistence test", "MIND", "CUSTOM", 80)
        val id = db.query("SELECT id FROM quests WHERE title = 'PERSIST ME' LIMIT 1", null).use { c -> c.moveToFirst(); c.getString(0) }
        assertTrue(repository.completeQuest(id).accepted)
        db.close()
        db = Room.databaseBuilder(context, KiraDatabase::class.java, dbName).allowMainThreadQueries().build()
        repository = KiraRepository(db)
        assertEquals(80L, db.dao().getPlayer()!!.totalXp)
        assertEquals("CUSTOM:ONCE", db.dao().getQuest(id)!!.completedPeriodKey)
    }
}
