package com.kira.system.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class XpProgression(val level: Int, val xp: Int, val totalXp: Long, val levelsGained: Int)

/** Pure rules shared by repositories and unit tests. */
object ProgressionRules {
    const val XP_PER_LEVEL = 200

    fun addXp(level: Int, xp: Int, totalXp: Long, awarded: Int): XpProgression {
        require(level >= 1 && xp in 0 until XP_PER_LEVEL && totalXp >= 0 && awarded >= 0)
        val combined = xp + awarded
        val levels = combined / XP_PER_LEVEL
        return XpProgression(level + levels, combined % XP_PER_LEVEL, totalXp + awarded, levels)
    }

    fun rankForLevel(level: Int): String = when {
        level >= 50 -> "S"
        level >= 35 -> "A"
        level >= 25 -> "B"
        level >= 15 -> "C"
        level >= 7 -> "D"
        else -> "E"
    }

    fun dailyPeriod(date: Date = Date()): String = "D:" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date)

    fun weeklyPeriod(date: Date = Date()): String {
        val calendar = Calendar.getInstance().apply {
            time = date
            firstDayOfWeek = Calendar.MONDAY
            minimalDaysInFirstWeek = 4
        }
        return "W:%04d-W%02d".format(Locale.US, calendar.getWeekYear(), calendar.get(Calendar.WEEK_OF_YEAR))
    }

    fun completionPeriod(schedule: String, date: Date = Date()): String = when (schedule) {
        "DAILY" -> dailyPeriod(date)
        "WEEKLY" -> weeklyPeriod(date)
        "CUSTOM" -> "CUSTOM:ONCE"
        else -> throw IllegalArgumentException("Unknown quest schedule: $schedule")
    }
}
