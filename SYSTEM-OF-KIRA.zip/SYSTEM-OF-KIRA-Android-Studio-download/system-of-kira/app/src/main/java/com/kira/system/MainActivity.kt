package com.kira.system

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kira.system.data.ActivityLog
import com.kira.system.data.PlayerState
import com.kira.system.data.QuestEntity
import com.kira.system.data.GameProgress
import com.kira.system.data.ShadowUnit
import com.kira.system.data.GearItem
import com.kira.system.data.SkillNode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Void = Color(0xFF070A10)
private val Panel = Color(0xFF0D1420)
private val Panel2 = Color(0xFF101D2B)
private val Neon = Color(0xFF35C8FF)
private val Ice = Color(0xFFB6F0FF)
private val Muted = Color(0xFF8295A9)
private val Purple = Color(0xFF9A7BFF)
private val Green = Color(0xFF63F4BD)

class MainActivity : ComponentActivity() {
    private val viewModel: KiraViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 10, 16)
        window.navigationBarColor = android.graphics.Color.rgb(7, 10, 16)
        setContent { KiraTheme { KiraApp(viewModel) } }
    }
}

@Composable private fun KiraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Neon, background = Void, surface = Panel, onPrimary = Void, onBackground = Color.White, onSurface = Color.White), content = content)
}

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("HOME", Icons.Default.GridView), QUESTS("QUESTS", Icons.Default.TrackChanges), ARMY("ARMY", Icons.Default.Groups), DUNGEONS("GATES", Icons.Default.Cyclone), PROFILE("PROFILE", Icons.Default.Person)
}

@Composable private fun KiraApp(vm: KiraViewModel) {
    val player by vm.player.collectAsStateWithLifecycle()
    val quests by vm.quests.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val game by vm.game.collectAsStateWithLifecycle()
    val studyCount by vm.studyCount.collectAsStateWithLifecycle()
    val workoutCount by vm.workoutCount.collectAsStateWithLifecycle()
    val studyMinutes by vm.studyMinutes.collectAsStateWithLifecycle()
    val workoutMinutes by vm.workoutMinutes.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val introPrefs = remember { context.getSharedPreferences("kira_intro", 0) }
    var selected by remember { mutableStateOf(Tab.HOME) }
    var awakened by remember { mutableStateOf(introPrefs.getBoolean("awakened", false)) }
    var createDialog by remember { mutableStateOf(false) }
    var logType by remember { mutableStateOf<String?>(null) }
    var toast by remember { mutableStateOf("") }
    var showLevelUp by remember { mutableStateOf(false) }
    val currentPlayer = player ?: PlayerState()
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(toast) { if (toast.isNotBlank()) { snackbarHostState.showSnackbar(toast); toast = "" } }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A1320), Void, Void)))) {
        if (!awakened) AwakeningScreen(onAwaken = { awakened = true; introPrefs.edit().putBoolean("awakened", true).apply() }) else Column(Modifier.fillMaxSize()) {
            TopBar(currentPlayer.streak)
            Box(Modifier.weight(1f)) {
                AnimatedContent(targetState = selected, label = "screen-transition") { tab ->
                    when (tab) {
                        Tab.HOME -> Dashboard(currentPlayer, quests, { quest -> vm.isDone(quest) }, onOpenQuests = { selected = Tab.QUESTS }, onComplete = { id -> vm.completeQuest(id) { accepted, level -> toast = when { level -> "LEVEL UP — YOUR POWER HAS INCREASED"; accepted -> "XP AWARDED · PROGRESS SAVED"; else -> "ALREADY COMPLETED FOR THIS PERIOD" }; showLevelUp = level } }, onLog = { logType = it })
                        Tab.QUESTS -> QuestsScreen(quests, { quest -> vm.isDone(quest) }, onComplete = { id -> vm.completeQuest(id) { accepted, level -> toast = when { level -> "LEVEL UP — ASCENSION COMPLETE"; accepted -> "QUEST COMPLETE · XP SAVED"; else -> "ALREADY COMPLETED FOR THIS PERIOD" }; showLevelUp = level } }, onCreate = { createDialog = true })
                        Tab.ARMY -> ArmyScreen(currentPlayer, quests, logs, game, vm)
                        Tab.DUNGEONS -> DungeonsScreen(currentPlayer.level, currentPlayer.totalXp, game, vm)
                        Tab.PROFILE -> ProfileScreen(currentPlayer, logs, studyCount, workoutCount, studyMinutes, workoutMinutes, onLog = { logType = it }, onSave = { name, sound, haptics -> vm.saveSettings(name, sound, haptics); toast = "PROFILE SAVED LOCALLY" })
                    }
                }
            }
            NavigationBar(containerColor = Color(0xFF090E16), contentColor = Neon, tonalElevation = 0.dp) {
                Tab.entries.forEach { tab -> NavigationBarItem(selected = selected == tab, onClick = { selected = tab }, icon = { Icon(tab.icon, null, Modifier.size(20.dp)) }, label = { Text(tab.label, fontSize = 9.sp, letterSpacing = .8.sp, fontWeight = FontWeight.Bold) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Neon, selectedTextColor = Neon, unselectedIconColor = Muted, unselectedTextColor = Muted, indicatorColor = Color(0xFF14283A))) }
            }
        }
        SnackbarHost(snackbarHostState, Modifier.align(Alignment.BottomCenter).padding(bottom = 82.dp))
        if (createDialog) CreateQuestDialog(onDismiss = { createDialog = false }, onCreate = { title, desc, cat, schedule, xp -> vm.createQuest(title, desc, cat, schedule, xp) { ok -> createDialog = false; toast = if (ok) "QUEST ADDED TO YOUR SYSTEM" else "COULD NOT CREATE QUEST" } })
        if (logType != null) ActivityLogDialog(type = logType!!, onDismiss = { logType = null }, onSave = { minutes, note -> vm.addLog(logType!!, minutes, note) { ok -> logType = null; toast = if (ok) "ACTIVITY LOGGED · XP UPDATED" else "CHECK THE DURATION AND TRY AGAIN" } })
        if (showLevelUp) LevelUpOverlay(onDismiss = { showLevelUp = false })
    }
}

@Composable private fun TopBar(streak: Int) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(Brush.linearGradient(listOf(Neon, Color(0xFF145078)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Bolt, null, tint = Void, modifier = Modifier.size(23.dp)) }
            Column { Text("SYSTEM OF KIRA", fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 1.7.sp); Text("PERSONAL AWAKENING OS", color = Muted, fontSize = 8.sp, letterSpacing = 1.3.sp) }
        }
        Row(Modifier.clip(CircleShape).border(1.dp, Color(0xFF24435A), CircleShape).background(Panel).padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.LocalFireDepartment, null, tint = Color(0xFFFFA45E), modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("$streak DAY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Ice) }
    }
}

@Composable private fun AwakeningScreen(onAwaken: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "awakening")
    val pulse by transition.animateFloat(.94f, 1.04f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF081626), Void, Color(0xFF05070C)))), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("SYSTEM INITIALIZATION", color = Neon, fontSize = 10.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
Spacer(Modifier.height(20.dp))
Image(
    painter = painterResource(R.drawable.shadow_warrior),
    contentDescription = null,
    modifier = Modifier
        .size(259.2.dp)
        .scale(pulse),
    contentScale = ContentScale.Fit
)            Spacer(Modifier.height(12.dp)); Text("THE OLD YOU\nENDS HERE.", fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp)); Text("No destiny. No shortcuts.\nOnly the person you choose to become.", color = Muted, textAlign = TextAlign.Center, fontSize = 13.sp, lineHeight = 21.sp)
            Spacer(Modifier.height(28.dp)); Button(onClick = onAwaken, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Void)) { Text("AWAKEN  ↗", fontWeight = FontWeight.Black, letterSpacing = 2.sp) }
            Spacer(Modifier.height(15.dp)); Text("YOUR JOURNEY. YOUR RULES. YOUR LEGACY.", color = Color(0xFF4C687E), fontSize = 8.sp, letterSpacing = 1.2.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable private fun Dashboard(player: PlayerState, quests: List<QuestEntity>, isDone: (QuestEntity) -> Boolean, onOpenQuests: () -> Unit, onComplete: (String) -> Unit, onLog: (String) -> Unit) {
    val daily = quests.filter { it.schedule == "DAILY" && !it.archived }
    val doneCount = daily.count(isDone)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(java.text.SimpleDateFormat("EEEE, MMM d", java.util.Locale.getDefault()).format(java.util.Date()).uppercase(), color = Neon, fontSize = 9.sp, letterSpacing = 1.4.sp); Spacer(Modifier.height(5.dp)); Text("BECOME\nUNSTOPPABLE.", fontSize = 28.sp, lineHeight = 32.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Black) }; Image(painterResource(R.drawable.shadow_warrior), null, Modifier.size(104.dp), contentScale = ContentScale.Fit) } }
        item { PlayerCard(player) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MiniStat("QUESTS TODAY", "$doneCount/${daily.size}", Icons.Default.CheckCircle, Green, Modifier.weight(1f)); MiniStat("TOTAL XP", player.totalXp.toString(), Icons.Default.Bolt, Neon, Modifier.weight(1f)); MiniStat("RANK", rankFor(player.level), Icons.Default.MilitaryTech, Purple, Modifier.weight(1f)) } }
        item { SectionHeader("DAILY DIRECTIVES", "${daily.size - doneCount} REMAINING", onOpenQuests) }
        if (daily.isEmpty()) item { EmptyCard("NO DAILY QUESTS", "Create a directive to begin your next run.", onOpenQuests) }
        items(daily.take(4), key = { it.id }) { quest -> QuestCard(quest, isDone(quest), onComplete = { onComplete(quest.id) }) }
        item { SectionHeader("TRAINING LOGS", "RECORD PROGRESS", null) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { ActionCard("STUDY LOG", "Focus minutes", Icons.Default.MenuBook, Purple, Modifier.weight(1f)) { onLog("STUDY") }; ActionCard("WORKOUT LOG", "Training minutes", Icons.Default.FitnessCenter, Green, Modifier.weight(1f)) { onLog("WORKOUT") } } }
        item { SectionCard("SYSTEM MESSAGE", "CONSISTENCY IS POWER", "Small completed actions compound. Earn XP by doing the work, not by waiting for motivation.", Icons.Default.Bolt, Neon) }
    }
}

@Composable private fun PlayerCard(player: PlayerState) {
    val progress by animateFloatAsState(targetValue = player.xp / 200f, animationSpec = tween(850, easing = FastOutSlowInEasing), label = "xp-progress")
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Color(0xFF132A3D), Color(0xFF0B121D), Color(0xFF10152A)))).border(1.dp, Color(0xFF24516B), RoundedCornerShape(20.dp)).padding(16.dp)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("PLAYER STATUS", color = Neon, fontSize = 9.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(player.displayName, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = .6.sp); Text("LEVEL ${player.level}  ·  ${rankFor(player.level)}-RANK HUNTER", color = Muted, fontSize = 9.sp, letterSpacing = .5.sp) }; Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFF0B1A29)).border(1.dp, Color(0xFF24516B), RoundedCornerShape(12.dp)).padding(10.dp)) { Icon(Icons.Default.Shield, null, tint = Neon, modifier = Modifier.size(28.dp)) } }
            Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("EXPERIENCE", color = Ice, fontSize = 9.sp, letterSpacing = 1.sp); Text("${player.xp} / 200 XP", color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp)); Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(Color(0xFF253849))) { Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape).background(Brush.horizontalGradient(listOf(Neon, Color(0xFF9AEFFF))))) }
            Spacer(Modifier.height(7.dp)); Text("${200 - player.xp} XP TO NEXT LEVEL", color = Muted, fontSize = 8.sp, letterSpacing = .8.sp)
        }
    }
}

@Composable private fun QuestsScreen(quests: List<QuestEntity>, isDone: (QuestEntity) -> Boolean, onComplete: (String) -> Unit, onCreate: () -> Unit) {
    var filter by remember { mutableStateOf("ALL") }
    val filtered = quests.filter { !it.archived && (filter == "ALL" || it.schedule == filter) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { PageHeading("QUEST DIRECTIVES", "Design your routine. Complete it. Evolve.") }
        item { Button(onClick = onCreate, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Void)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("CREATE NEW QUEST", fontWeight = FontWeight.Black, letterSpacing = 1.sp) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { listOf("ALL", "DAILY", "WEEKLY", "CUSTOM").forEach { key -> FilterChip(selected = filter == key, onClick = { filter = key }, label = { Text(key, fontSize = 10.sp) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF17344A), selectedLabelColor = Neon)) } } }
        item { MiniStat("ACTIVE DIRECTIVES", filtered.size.toString(), Icons.Default.TrackChanges, Neon, Modifier.fillMaxWidth()) }
        if (filtered.isEmpty()) item { EmptyCard("NOTHING IN THIS QUEUE", "Create a daily, weekly, or one-time custom quest.", onCreate) }
        items(filtered, key = { it.id }) { quest -> QuestCard(quest, isDone(quest), onComplete = { onComplete(quest.id) }, expanded = true) }
        item { Text("Daily and weekly quests become available again in their next period. Custom quests can only award XP once.", color = Muted, fontSize = 10.sp, lineHeight = 16.sp) }
    }
}

@Composable private fun CreateQuestDialog(onDismiss: () -> Unit, onCreate: (String, String, String, String, Int) -> Unit) {
    var title by remember { mutableStateOf("") }; var description by remember { mutableStateOf("") }; var category by remember { mutableStateOf("MIND") }; var schedule by remember { mutableStateOf("DAILY") }; var xpText by remember { mutableStateOf("40") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel2, title = { Text("NEW DIRECTIVE", fontWeight = FontWeight.Black, letterSpacing = 1.sp) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(11.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Quest title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(description, { description = it }, label = { Text("Description / goal") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Text("SCHEDULE", color = Neon, fontSize = 10.sp, letterSpacing = 1.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("DAILY", "WEEKLY", "CUSTOM").forEach { key -> FilterChip(selected = schedule == key, onClick = { schedule = key }, label = { Text(key, fontSize = 9.sp) }) } }
            Text("CATEGORY", color = Neon, fontSize = 10.sp, letterSpacing = 1.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("MIND", "BODY", "VITALS").forEach { key -> FilterChip(selected = category == key, onClick = { category = key }, label = { Text(key, fontSize = 9.sp) }) } }
            OutlinedTextField(xpText, { xpText = it.filter(Char::isDigit).take(3) }, label = { Text("XP reward (5–500)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
        }
    }, confirmButton = { TextButton(onClick = { val xp = xpText.toIntOrNull() ?: 40; if (title.isNotBlank() && xp in 5..500) onCreate(title, description, category, schedule, xp) }, enabled = title.isNotBlank() && (xpText.toIntOrNull() ?: 0) in 5..500) { Text("CREATE", color = Neon, fontWeight = FontWeight.Bold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL", color = Muted) } })
}

@Composable private fun ActivityLogDialog(type: String, onDismiss: () -> Unit, onSave: (Int, String) -> Unit) {
    var minutes by remember { mutableStateOf("25") }; var note by remember { mutableStateOf("") }
    val study = type == "STUDY"
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel2, title = { Text(if (study) "STUDY SESSION" else "WORKOUT SESSION", fontWeight = FontWeight.Black, letterSpacing = 1.sp) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(if (study) "Log focused learning time." else "Log your training time.", color = Muted, fontSize = 12.sp)
            OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit).take(3) }, label = { Text("Minutes (1–600)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(note, { note = it }, label = { Text("Notes (optional)") }, modifier = Modifier.fillMaxWidth())
            Text("A saved log awards XP and stays in your activity history.", color = Neon, fontSize = 10.sp)
        }
    }, confirmButton = { TextButton(onClick = { minutes.toIntOrNull()?.takeIf { it in 1..600 }?.let { onSave(it, note) } }, enabled = (minutes.toIntOrNull() ?: 0) in 1..600) { Text("SAVE LOG", color = Neon, fontWeight = FontWeight.Bold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL", color = Muted) } })
}

@Composable private fun ArmyScreen(player: PlayerState, quests: List<QuestEntity>, logs: List<ActivityLog>, game: GameProgress, vm: KiraViewModel) {
    var section by remember { mutableStateOf("ARMY") }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { PageHeading("SHADOW COMMAND", "Build the legion. Shape the sovereign.") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) { listOf("ARMY", "GEAR", "SKILLS", "REPORTS").forEach { label -> Surface(onClick = { section = label }, color = if(section==label) Color(0xFF153047) else Panel, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, if(section==label) Neon else Color(0xFF223446)), modifier = Modifier.weight(1f)) { Text(label, modifier = Modifier.padding(vertical=11.dp), textAlign=TextAlign.Center, color=if(section==label) Neon else Muted, fontSize=9.sp, fontWeight=FontWeight.Black) } } } }
        when(section) {
            "ARMY" -> {
                item { Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) { MiniStat("SHADOWS", game.units.size.toString(), Icons.Default.Groups, Purple, Modifier.weight(1f)); MiniStat("MATERIALS", game.materials.toString(), Icons.Default.Diamond, Neon, Modifier.weight(1f)); MiniStat("GATE WINS", game.wins.toString(), Icons.Default.EmojiEvents, Green, Modifier.weight(1f)) } }
                item { SectionCard("COMMAND HIERARCHY", "SHADOW SOVEREIGN → COMMANDER → LEGION", "Noct leads the vanguard. Vesper coordinates reconnaissance. Onyx anchors the defensive line. Riven supports the rear formation.", Icons.Default.AccountTree, Neon) }
                items(game.units, key={it.id}) { unit -> ShadowUnitCard(unit, onTrain={vm.trainUnit(unit.id)}, onEvolve={vm.trainUnit(unit.id,true)}) }
                item { Text("Evolution requires a unit at level 10 and 3 materials. Training costs 1 material.", color=Muted, fontSize=10.sp) }
            }
            "GEAR" -> {
                item { SectionCard("FORGE", "CRAFT THE UMBRA", "Combine 2 common materials into one Umbra Shard. Gear upgrades cost 2 materials and increase power.", Icons.Default.Build, Purple) }
                item { Button(onClick={vm.craftShard()}, enabled=game.materials>=2, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF153047))) { Text("CRAFT UMBRA SHARD · 2 MATERIALS") } }
                items(game.items, key={it.id}) { item -> GearCard(item, onEquip={vm.equipItem(item.id)}, onUpgrade={vm.upgradeItem(item.id)}) }
            }
            "SKILLS" -> {
                item { Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) { MiniStat("SKILL POINTS", game.materials.toString(), Icons.Default.Bolt, Neon, Modifier.weight(1f)); MiniStat("UNLOCKED", game.skills.count{it.unlocked}.toString(), Icons.Default.AccountTree, Purple, Modifier.weight(1f)) } }
                items(game.skills, key={it.id}) { skill -> SkillCard(skill, onUnlock={vm.unlockSkill(skill.id)}) }
                item { Text("Phantom Strike is always available. Echo Cut changes your attack action; Focused Mind and Shadow Sovereign add passive combat bonuses.", color=Muted, fontSize=10.sp, lineHeight=15.sp) }
            }
            else -> {
                item { PageHeading("FIELD REPORTS", "Weekly discipline. Fictional victories.") }
                val since = System.currentTimeMillis()-7L*24*60*60*1000
                val weeklyLogs=logs.filter{it.createdAt>=since}
                val weeklyQuests=quests.count{it.completedPeriodKey?.let { key -> key.startsWith("D:") || key.startsWith("W:") || key=="CUSTOM:ONCE" }==true && it.createdAt>=since}
                item { Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) { MiniStat("7D STUDY MIN", weeklyLogs.filter{it.type=="STUDY"}.sumOf{it.minutes}.toString(), Icons.Default.MenuBook, Purple, Modifier.weight(1f)); MiniStat("7D WORKOUT MIN", weeklyLogs.filter{it.type=="WORKOUT"}.sumOf{it.minutes}.toString(), Icons.Default.FitnessCenter, Green, Modifier.weight(1f)) } }
                item { Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) { MiniStat("QUESTS CLEARED", weeklyQuests.toString(), Icons.Default.CheckCircle, Neon, Modifier.weight(1f)); MiniStat("RPG WINS", game.wins.toString(), Icons.Default.EmojiEvents, Color(0xFFFFC46B), Modifier.weight(1f)) } }
                item { SectionCard("RANK · ${rankFor(player.level)}", "ACHIEVEMENT ARCHIVE", (game.rankAchievements + listOfNotNull(if(player.level>=7) "D-RANK AWAKENED" else null, if(player.level>=15) "C-RANK ASCENSION" else null, if(player.level>=25) "B-RANK BREAKTHROUGH" else null, if(player.level>=35) "A-RANK SOVEREIGN" else null, if(player.level>=50) "S-RANK TRANSCENDENCE" else null, if(game.wins>=1) "FIRST GATE CLEARED" else null, if(game.wins>=5) "GATE BREAKER" else null)).distinct().joinToString("  /  ").ifBlank{"No achievements recorded yet"}, Icons.Default.MilitaryTech, Neon) }
                item { SectionHeader("XP HISTORY", "LATEST ${game.xpHistory.size}", null) }
                if(game.xpHistory.isEmpty()) item { EmptyCard("NO GATE RECORDS", "Win a fictional dungeon battle to record XP history.", null) }
                items(game.xpHistory.take(20)) { entry -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(13.dp), verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(entry.label, fontSize=11.sp, fontWeight=FontWeight.Bold); Text(SimpleDateFormat("dd MMM · HH:mm", Locale.getDefault()).format(Date(entry.time)), fontSize=9.sp, color=Muted) }; Text("+${entry.amount} XP", color=Neon, fontWeight=FontWeight.Black, fontSize=11.sp) } }
                item { Text("Real-life study and workout logs are separate from fictional battle rewards.", color=Muted, fontSize=10.sp) }
            }
        }
    }
}

@Composable private fun ShadowUnitCard(unit: ShadowUnit, onTrain:()->Unit, onEvolve:()->Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).border(1.dp, rarityColor(unit.rarity).copy(alpha=.7f), RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { Image(painterResource(R.drawable.shadow_warrior), null, Modifier.size(70.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(unit.name, fontSize=17.sp, fontWeight=FontWeight.Black, letterSpacing=1.2.sp); Text("${unit.rarity} · ${unit.role.uppercase()}", color=rarityColor(unit.rarity), fontSize=9.sp, fontWeight=FontWeight.Bold); Text("LV ${unit.level} · EVOLUTION ${unit.evolution}", color=Neon, fontSize=10.sp); Text("ABILITY · ${unit.ability}", color=Muted, fontSize=9.sp) }; Icon(Icons.Default.Verified, null, tint=rarityColor(unit.rarity), modifier=Modifier.size(20.dp)) }
        Text("COMMANDER: ${unit.commander.uppercase()}", color=Muted, fontSize=9.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick=onTrain, modifier=Modifier.weight(1f), contentPadding=PaddingValues(4.dp)) { Text("TRAIN · 1 MAT", fontSize=9.sp) }; OutlinedButton(onClick=onEvolve, enabled=unit.level>=10, modifier=Modifier.weight(1f), contentPadding=PaddingValues(4.dp)) { Text("EVOLVE · 3 MAT", fontSize=9.sp) } }
    }
}

@Composable private fun GearCard(item: GearItem, onEquip:()->Unit, onUpgrade:()->Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).border(1.dp, rarityColor(item.rarity).copy(alpha=.65f), RoundedCornerShape(15.dp)).padding(13.dp), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(45.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF142538)), contentAlignment=Alignment.Center) { Icon(if(item.slot=="Weapon") Icons.Default.Gavel else if(item.slot=="Relic") Icons.Default.Shield else Icons.Default.Diamond, null, tint=rarityColor(item.rarity), modifier=Modifier.size(24.dp)) }
        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(item.name, fontWeight=FontWeight.Black, fontSize=11.sp); Text("${item.rarity} · ${item.slot} · ${if(item.slot=="Material") "x${item.count}" else "+${item.power} POWER · LV ${item.level}"}", color=Muted, fontSize=9.sp); if(item.equipped) Text("EQUIPPED", color=Green, fontSize=8.sp, fontWeight=FontWeight.Bold) }
        if(item.slot!="Material") Column { TextButton(onClick=onEquip, contentPadding=PaddingValues(3.dp)) { Text(if(item.equipped) "ON" else "EQUIP", fontSize=9.sp, color=Neon) }; TextButton(onClick=onUpgrade, contentPadding=PaddingValues(3.dp)) { Text("UPGRADE", fontSize=8.sp, color=Purple) } }
    }
}

@Composable private fun SkillCard(skill: SkillNode, onUnlock:()->Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).border(1.dp, if(skill.unlocked) Neon.copy(alpha=.65f) else Color(0xFF243446), RoundedCornerShape(15.dp)).padding(13.dp), verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF142538)), contentAlignment=Alignment.Center) { Icon(if(skill.unlocked) Icons.Default.Bolt else Icons.Default.Lock, null, tint=if(skill.unlocked) Neon else Muted) }; Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text(skill.name, fontSize=11.sp, fontWeight=FontWeight.Black); Text(skill.description, color=Muted, fontSize=9.sp, lineHeight=14.sp); Text(if(skill.unlocked) "UNLOCKED" else "COST · ${skill.cost} MATERIALS", color=if(skill.unlocked) Green else Purple, fontSize=8.sp, fontWeight=FontWeight.Bold) }; if(!skill.unlocked) TextButton(onClick=onUnlock) { Text("UNLOCK", color=Neon, fontSize=9.sp) } }
}

private fun rarityColor(rarity:String):Color = when(rarity) { "EPIC" -> Purple; "RARE" -> Neon; "LEGENDARY" -> Color(0xFFFFC46B); else -> Muted }

@Composable private fun DungeonsScreen(level: Int, totalXp: Long, game: GameProgress, vm: KiraViewModel) {
    val battle=game.battle
    LazyColumn(Modifier.fillMaxSize(), contentPadding=PaddingValues(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { PageHeading(if(battle.active) "COMBAT INTERFACE" else "DUNGEON GATES", if(battle.active) "Turn ${battle.turn} · threat detected" else "Choose a route. Claim the gate.") }
        if(battle.active) {
            item { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(Color(0xFF182D43),Color(0xFF0A101A)))).border(1.dp, if(battle.boss) Purple else Neon, RoundedCornerShape(22.dp)).padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text(if(battle.boss) "BOSS ENCOUNTER · PHASE ${battle.bossPhase}" else "ENEMY ENCOUNTER · STAGE ${battle.stage}", color=if(battle.boss) Purple else Neon, fontSize=9.sp, fontWeight=FontWeight.Black, letterSpacing=1.5.sp)
                Text(battle.enemyName, fontSize=24.sp, fontWeight=FontWeight.Black, letterSpacing=1.sp)
                Text("${battle.dungeonName} · ${if(battle.boss) "OVERLORD" else "GATE ENEMY"}", color=Muted, fontSize=10.sp)
                Text("ENEMY VITALITY  ${battle.enemyHp} / ${battle.enemyMaxHp}", color=Ice, fontSize=10.sp, fontWeight=FontWeight.Bold)
                LinearProgressIndicator(progress={battle.enemyHp.toFloat()/battle.enemyMaxHp.coerceAtLeast(1)}, modifier=Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color=if(battle.boss) Purple else Neon, trackColor=Color(0xFF26313E))
                Text("PLAYER HP  ${battle.playerHp} / ${if(game.skills.any{it.id=="focus"&&it.unlocked}) 110 else 100}", color=Green, fontSize=10.sp, fontWeight=FontWeight.Bold)
                LinearProgressIndicator(progress={battle.playerHp.toFloat()/(if(game.skills.any{it.id=="focus"&&it.unlocked}) 110f else 100f)}, modifier=Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color=Green, trackColor=Color(0xFF26313E))
                Text("Your turn. Choose an unlocked combat technique.", color=Muted, fontSize=10.sp)
                game.skills.filter{it.unlocked}.forEach { skill -> Button(onClick={vm.battleTurn(skill.id)}, modifier=Modifier.fillMaxWidth(), enabled=battle.active, colors=ButtonDefaults.buttonColors(containerColor=if(skill.id=="strike") Color(0xFF17415A) else Color(0xFF292047))) { Text("${skill.name}  ·  ${skill.description}", fontSize=10.sp) } }
                OutlinedButton(onClick={vm.retreatBattle()}, modifier=Modifier.fillMaxWidth()) { Text("RETREAT FROM GATE", color=Muted) }
            } }
        } else if(battle.result=="VICTORY") {
            item { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Panel).border(1.dp,Green,RoundedCornerShape(22.dp)).padding(22.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(10.dp)) { Icon(Icons.Default.EmojiEvents,null,tint=Green,modifier=Modifier.size(48.dp)); Text("GATE CLEARED",color=Green,fontSize=23.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp); Text("${battle.dungeonName} · ${if(battle.boss) "BOSS DEFEATED" else "ENEMY DEFEATED"}",color=Ice,fontSize=10.sp); Text("Reward: XP recorded in the RPG report · materials added to inventory",color=Muted,fontSize=10.sp,textAlign=TextAlign.Center); Button(onClick={vm.claimVictory()}, modifier=Modifier.fillMaxWidth()) { Text("CLAIM REWARDS") } } }
        } else if(battle.result=="DEFEAT") {
            item { SectionCard("BATTLE RESULT", "YOUR SHADOW RETREATS", "This is a fictional encounter. No real-life workout or study task was affected. Start another gate when ready.", Icons.Default.Refresh, Purple) }
            item { Button(onClick={vm.retreatBattle()}, modifier=Modifier.fillMaxWidth()) { Text("RETURN TO GATE SELECT") } }
        } else {
            item { SectionCard("ROUTE A · ARCHIVE", "THE ENDLESS ARCHIVE", "Branch A — spectral scribes and memory wraiths. Standard enemy, tactical turn-based encounter.", Icons.Default.MenuBook, Neon) }
            item { Button(onClick={ vm.startBattle("archive","THE ENDLESS ARCHIVE",1,false) }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF153047))) { Text("ENTER ROUTE A · STANDARD GATE") } }
            item { SectionCard("ROUTE B · IRON", "IRON SANCTUM", "Branch B — ash stalkers guard the forge route. Enemies scale with the selected stage.", Icons.Default.FitnessCenter, Green) }
            item { Button(onClick={ vm.startBattle("sanctum","IRON SANCTUM",3,false) }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF153047))) { Text("ENTER ROUTE B · ELITE GATE") } }
            item { SectionCard("ROUTE C · ABYSS", "VOID CHAMBER", "Boss route — the Gate Overlord has two phases and a heavier attack after losing half its vitality.", Icons.Default.Cyclone, Purple) }
            item { Button(onClick={ vm.startBattle("abyss","VOID CHAMBER",5,true) }, modifier=Modifier.fillMaxWidth(), enabled=level>=3, colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF292047))) { Text(if(level>=3) "CHALLENGE THE GATE OVERLORD" else "BOSS GATE · REQUIRES LEVEL 3") } }
            item { Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) { MiniStat("GATE WINS", game.wins.toString(), Icons.Default.EmojiEvents, Green, Modifier.weight(1f)); MiniStat("MATERIALS", game.materials.toString(), Icons.Default.Diamond, Neon, Modifier.weight(1f)); MiniStat("LIFETIME XP", totalXp.toString(), Icons.Default.Bolt, Purple, Modifier.weight(1f)) } }
        }
        item { Text("All combat is fictional, turn-based RPG gameplay. Battle rewards never count as exercise completion.", color=Muted, fontSize=10.sp, lineHeight=15.sp) }
    }
}

@Composable private fun ProfileScreen(player: PlayerState, logs: List<ActivityLog>, studyCount: Int, workoutCount: Int, studyMinutes: Int, workoutMinutes: Int, onLog: (String) -> Unit, onSave: (String, Boolean, Boolean) -> Unit) {
    var name by remember(player.displayName) { mutableStateOf(player.displayName) }; var sound by remember(player.soundEnabled) { mutableStateOf(player.soundEnabled) }; var haptics by remember(player.hapticsEnabled) { mutableStateOf(player.hapticsEnabled) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PageHeading("PLAYER PROFILE", "Your progress. Your settings. Saved on-device.") }
        item { PlayerCard(player) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MiniStat("STUDY LOGS", studyCount.toString(), Icons.Default.MenuBook, Purple, Modifier.weight(1f)); MiniStat("WORKOUT LOGS", workoutCount.toString(), Icons.Default.FitnessCenter, Green, Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MiniStat("STUDY MIN", studyMinutes.toString(), Icons.Default.Psychology, Purple, Modifier.weight(1f)); MiniStat("TRAINING MIN", workoutMinutes.toString(), Icons.Default.Favorite, Green, Modifier.weight(1f)) } }
        item { SectionHeader("ACTIVITY HISTORY", "LATEST ${logs.size}", null) }
        if (logs.isEmpty()) item { EmptyCard("NO ACTIVITY RECORDED", "Log a study session or workout to begin your history.", null) }
        items(logs.take(12), key = { it.id }) { log -> LogCard(log) }
        item { SectionHeader("TRAINING SHORTCUTS", "ADD A LOG", null) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { ActionCard("STUDY LOG", "Record focus", Icons.Default.MenuBook, Purple, Modifier.weight(1f)) { onLog("STUDY") }; ActionCard("WORKOUT LOG", "Record training", Icons.Default.FitnessCenter, Green, Modifier.weight(1f)) { onLog("WORKOUT") } } }
        item { SectionCard("SYSTEM PREFERENCES", "LOCAL PROFILE", "Your profile and preference toggles are saved in the local Room database.", Icons.Default.Settings, Neon) }
        item { OutlinedTextField(name, { name = it }, label = { Text("Hunter display name") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { PreferenceRow("SOUND CUES", "Ready for future sound effects", sound) { sound = it } }
        item { PreferenceRow("HAPTIC FEEDBACK", "Ready for future haptic cues", haptics) { haptics = it } }
        item { Button(onClick = { onSave(name, sound, haptics) }, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Void), shape = RoundedCornerShape(12.dp)) { Text("SAVE PROFILE & SETTINGS", fontWeight = FontWeight.Black, letterSpacing = .7.sp) } }
    }
}

@Composable private fun PreferenceRow(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold, fontSize = 11.sp); Text(subtitle, color = Muted, fontSize = 10.sp) }; Switch(checked, onCheckedChange = onChecked, colors = SwitchDefaults.colors(checkedThumbColor = Void, checkedTrackColor = Neon)) } }
@Composable private fun LogCard(log: ActivityLog) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).border(1.dp, Color(0xFF1D2B3A), RoundedCornerShape(14.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (log.type == "STUDY") Icons.Default.MenuBook else Icons.Default.FitnessCenter, null, tint = if (log.type == "STUDY") Purple else Green, modifier = Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("${log.type} SESSION · ${log.minutes} MIN", fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(log.note.ifBlank { "No note added" }, color = Muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }; Text("+${log.xpAwarded} XP", color = Neon, fontWeight = FontWeight.Bold, fontSize = 10.sp) } }

@Composable private fun QuestCard(quest: QuestEntity, done: Boolean, onComplete: () -> Unit, expanded: Boolean = false) {
    val icon = when (quest.category) { "BODY", "WORKOUT" -> Icons.Default.FitnessCenter; "STUDY", "MIND" -> Icons.Default.MenuBook; "VITALS" -> Icons.Default.WaterDrop; else -> Icons.Default.Bolt }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (done) Color(0xFF0C211F) else Panel).border(1.dp, if (done) Color(0xFF245D50) else Color(0xFF1D2B3A), RoundedCornerShape(16.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(43.dp).clip(RoundedCornerShape(12.dp)).background(if (done) Color(0xFF153E37) else Color(0xFF15283A)), contentAlignment = Alignment.Center) { Icon(if (done) Icons.Default.Check else icon, null, tint = if (done) Green else Neon, modifier = Modifier.size(21.dp)) }
        Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text(quest.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .3.sp); Spacer(Modifier.height(4.dp)); Text(quest.description.ifBlank { "Complete this directive." }, fontSize = 10.sp, color = Muted, maxLines = if (expanded) 3 else 2, overflow = TextOverflow.Ellipsis); Spacer(Modifier.height(5.dp)); Text("+${quest.xpReward} XP  ·  ${quest.schedule}", fontSize = 9.sp, color = if (done) Green else Neon, letterSpacing = .4.sp) }
        Spacer(Modifier.width(6.dp)); if (done) Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(22.dp)) else IconButton(onClick = onComplete, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.AddCircle, "Complete quest", tint = Neon, modifier = Modifier.size(25.dp)) }
    }
}

@Composable private fun MiniStat(label: String, value: String, icon: ImageVector, tint: Color, modifier: Modifier = Modifier) { Column(modifier.clip(RoundedCornerShape(15.dp)).background(Panel).border(1.dp, Color(0xFF1B2A3A), RoundedCornerShape(15.dp)).padding(12.dp)) { Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp)); Spacer(Modifier.height(10.dp)); Text(value, fontSize = 20.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(label, fontSize = 8.sp, color = Muted, letterSpacing = .7.sp, maxLines = 1) } }
@Composable private fun SectionHeader(title: String, action: String, onClick: (() -> Unit)?) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text(title, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp); Text(action, color = Neon, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = if (onClick != null) Modifier.clickable(onClick = onClick).padding(4.dp) else Modifier.padding(4.dp)) } }
@Composable private fun PageHeading(title: String, subtitle: String) { Column { Text(title, color = Neon, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(subtitle, fontSize = 21.sp, lineHeight = 26.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(5.dp)); Box(Modifier.width(62.dp).height(3.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(Neon, Purple)))) } }
@Composable private fun SectionCard(eyebrow: String, title: String, description: String, icon: ImageVector, tint: Color) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Panel).border(1.dp, Color(0xFF1D2B3A), RoundedCornerShape(17.dp)).padding(15.dp), verticalAlignment = Alignment.Top) { Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF142538)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(23.dp)) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(eyebrow, color = tint, fontSize = 8.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(title, fontSize = 13.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(5.dp)); Text(description, color = Muted, fontSize = 10.sp, lineHeight = 16.sp) } } }
@Composable private fun ActionCard(title: String, subtitle: String, icon: ImageVector, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) { Column(modifier.clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Color(0xFF1D2B3A), RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(13.dp)) { Icon(icon, null, tint = tint, modifier = Modifier.size(23.dp)); Spacer(Modifier.height(12.dp)); Text(title, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = .4.sp); Spacer(Modifier.height(4.dp)); Text(subtitle, fontSize = 9.sp, color = Muted) } }
@Composable private fun EmptyCard(title: String, description: String, onClick: (() -> Unit)?) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).border(BorderStroke(1.dp, Color(0xFF1D2B3A)), RoundedCornerShape(16.dp)).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox, null, tint = Muted, modifier = Modifier.size(28.dp)); Spacer(Modifier.height(9.dp)); Text(title, fontSize = 11.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(4.dp)); Text(description, color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center, lineHeight = 15.sp) } }
@Composable private fun LevelUpOverlay(onDismiss: () -> Unit) { val transition = rememberInfiniteTransition(label = "levelup"); val scale by transition.animateFloat(.97f, 1.04f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "levelup-pulse"); Box(Modifier.fillMaxSize().background(Color(0xD900060D)).clickable(onClick = onDismiss), contentAlignment = Alignment.Center) { Column(Modifier.fillMaxWidth().padding(28.dp).scale(scale).clip(RoundedCornerShape(24.dp)).background(Brush.verticalGradient(listOf(Color(0xFF163A53), Color(0xFF0A111D)))).border(1.dp, Neon, RoundedCornerShape(24.dp)).padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Bolt, null, tint = Neon, modifier = Modifier.size(52.dp)); Spacer(Modifier.height(12.dp)); Text("LEVEL UP", color = Neon, fontSize = 29.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp); Text("YOUR SHADOW GROWS STRONGER", textAlign = TextAlign.Center, color = Ice, fontSize = 10.sp, letterSpacing = 1.sp); Spacer(Modifier.height(20.dp)); Text("TAP TO CONTINUE", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp) } } }
private fun rankFor(level: Int): String = when { level >= 50 -> "S"; level >= 35 -> "A"; level >= 25 -> "B"; level >= 15 -> "C"; level >= 7 -> "D"; else -> "E" }
