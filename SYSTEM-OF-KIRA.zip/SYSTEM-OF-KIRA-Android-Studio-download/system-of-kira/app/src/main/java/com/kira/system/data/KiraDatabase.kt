package com.kira.system.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface KiraDao {
    @Query("SELECT * FROM quests WHERE archived = 0 ORDER BY createdAt DESC")
    fun observeQuests(): Flow<List<QuestEntity>>

    @Query("SELECT * FROM quests WHERE id = :id LIMIT 1")
    suspend fun getQuest(id: String): QuestEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertQuest(quest: QuestEntity)

    @Update
    suspend fun updateQuest(quest: QuestEntity)

    @Query("SELECT * FROM player_state WHERE id = 1 LIMIT 1")
    fun observePlayer(): Flow<PlayerState?>

    @Query("SELECT * FROM player_state WHERE id = 1 LIMIT 1")
    suspend fun getPlayer(): PlayerState?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlayer(player: PlayerState)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertLog(log: ActivityLog)

    @Query("SELECT * FROM activity_logs ORDER BY createdAt DESC LIMIT 100")
    fun observeLogs(): Flow<List<ActivityLog>>

    @Query("SELECT COUNT(*) FROM activity_logs WHERE type = :type")
    fun observeLogCount(type: String): Flow<Int>

    @Query("SELECT COALESCE(SUM(minutes), 0) FROM activity_logs WHERE type = :type")
    fun observeLogMinutes(type: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM quests WHERE completedPeriodKey = :periodKey AND archived = 0")
    suspend fun completedCount(periodKey: String): Int

    @Query("SELECT * FROM game_save WHERE id = 1 LIMIT 1")
    fun observeGameSave(): Flow<GameSaveEntity?>

    @Query("SELECT * FROM game_save WHERE id = 1 LIMIT 1")
    suspend fun getGameSave(): GameSaveEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveGameSave(save: GameSaveEntity)

    @Transaction
    suspend fun seedIfNeeded(seedQuests: List<QuestEntity>) {
        if (getPlayer() == null) savePlayer(PlayerState())
        if (getQuest("seed-move") == null) seedQuests.forEach { quest ->
            if (getQuest(quest.id) == null) insertQuest(quest)
        }
    }
}

@Database(entities = [QuestEntity::class, PlayerState::class, ActivityLog::class, GameSaveEntity::class], version = 2, exportSchema = false)
abstract class KiraDatabase : RoomDatabase() {
    abstract fun dao(): KiraDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("CREATE TABLE IF NOT EXISTS game_save (id INTEGER NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(id))") }
        }
        @Volatile private var instance: KiraDatabase? = null
        fun get(context: Context): KiraDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, KiraDatabase::class.java, "system_of_kira.db")
                .addMigrations(MIGRATION_1_2)
                .fallbackToDestructiveMigration()
                .build().also { instance = it }
        }
    }
}
