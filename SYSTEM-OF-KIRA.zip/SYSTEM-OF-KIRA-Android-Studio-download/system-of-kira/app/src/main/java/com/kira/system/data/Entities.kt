package com.kira.system.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quests")
data class QuestEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val schedule: String,
    val xpReward: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val completedPeriodKey: String? = null,
    val archived: Boolean = false
)

@Entity(tableName = "player_state")
data class PlayerState(
    @PrimaryKey val id: Int = 1,
    val level: Int = 1,
    val xp: Int = 0,
    val totalXp: Long = 0,
    val streak: Int = 0,
    val lastActiveDate: String = "",
    val displayName: String = "SHADOW WALKER",
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true
)

@Entity(tableName = "activity_logs")
data class ActivityLog(
    @PrimaryKey val id: String,
    val type: String,
    val minutes: Int,
    val note: String,
    val createdAt: Long = System.currentTimeMillis(),
    val xpAwarded: Int
)
