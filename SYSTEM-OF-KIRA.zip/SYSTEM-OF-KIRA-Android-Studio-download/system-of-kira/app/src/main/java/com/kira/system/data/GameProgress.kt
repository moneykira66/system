package com.kira.system.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

@Entity(tableName = "game_save")
data class GameSaveEntity(@PrimaryKey val id: Int = 1, val payload: String)

data class ShadowUnit(val id:String,val name:String,val role:String,val rarity:String,val level:Int,val evolution:Int,val ability:String,val commander:String)
data class GearItem(val id:String,val name:String,val slot:String,val rarity:String,val power:Int,val level:Int,val count:Int,val equipped:Boolean)
data class SkillNode(val id:String,val name:String,val description:String,val cost:Int,val unlocked:Boolean)
data class BattleState(val active:Boolean=false,val dungeon:String="",val dungeonName:String="",val stage:Int=1,val playerHp:Int=100,val enemyHp:Int=80,val enemyMaxHp:Int=80,val enemyName:String="GATE WRAITH",val boss:Boolean=false,val bossPhase:Int=1,val turn:Int=1,val result:String="",val battleId:String="")
data class XpEntry(val label:String,val amount:Int,val time:Long)
data class GameProgress(val units:List<ShadowUnit>,val items:List<GearItem>,val skills:List<SkillNode>,val battle:BattleState,val materials:Int,val wins:Int,val rankAchievements:List<String>,val xpHistory:List<XpEntry>) {
    companion object {
        fun fresh() = GameProgress(
            units=listOf(
                ShadowUnit("noct","NOCT","Vanguard","EPIC",12,1,"Abyssal Cleave","Commander"),
                ShadowUnit("vesper","VESPER","Scout","RARE",9,0,"Nightstep","Noct"),
                ShadowUnit("onyx","ONYX","Guardian","RARE",7,0,"Umbral Ward","Noct"),
                ShadowUnit("riven","RIVEN","Arcanist","COMMON",4,0,"Void Spark","Vesper")
            ),
            items=listOf(
                GearItem("edge","ECLIPSE EDGE","Weapon","EPIC",18,1,1,true),
                GearItem("mantle","NIGHT MANTLE","Relic","RARE",10,1,1,true),
                GearItem("core","VOID CORE","Material","COMMON",0,1,4,false),
                GearItem("shard","UMBRA SHARD","Material","RARE",0,1,2,false)
            ),
            skills=listOf(
                SkillNode("strike","PHANTOM STRIKE","Deal heavy damage to a gate enemy.",0,true),
                SkillNode("focus","FOCUSED MIND","Passive +10 max battle HP.",1,false),
                SkillNode("echo","ECHO CUT","A fast double strike.",2,false),
                SkillNode("sovereign","SHADOW SOVEREIGN","Passive +20% damage.",4,false)
            ), battle=BattleState(), materials=4, wins=0, rankAchievements=listOf("FIRST AWAKENING"), xpHistory=emptyList()
        )
        fun from(json:String?):GameProgress = runCatching {
            val o=JSONObject(json ?: return fresh())
            val units=o.getJSONArray("units").toModels { ShadowUnit(it.getString("id"),it.getString("name"),it.getString("role"),it.getString("rarity"),it.getInt("level"),it.getInt("evolution"),it.getString("ability"),it.getString("commander")) }
            val items=o.getJSONArray("items").toModels { GearItem(it.getString("id"),it.getString("name"),it.getString("slot"),it.getString("rarity"),it.getInt("power"),it.getInt("level"),it.getInt("count"),it.getBoolean("equipped")) }
            val skills=o.getJSONArray("skills").toModels { SkillNode(it.getString("id"),it.getString("name"),it.getString("description"),it.getInt("cost"),it.getBoolean("unlocked")) }
            val b=o.getJSONObject("battle")
            val battle=BattleState(b.getBoolean("active"),b.getString("dungeon"),b.getString("dungeonName"),b.getInt("stage"),b.getInt("playerHp"),b.getInt("enemyHp"),b.getInt("enemyMaxHp"),b.getString("enemyName"),b.getBoolean("boss"),b.getInt("bossPhase"),b.getInt("turn"),b.getString("result"),b.getString("battleId"))
            val hist=o.getJSONArray("xpHistory").toModels { XpEntry(it.getString("label"),it.getInt("amount"),it.getLong("time")) }
            GameProgress(units,items,skills,battle,o.getInt("materials"),o.getInt("wins"),o.getJSONArray("rankAchievements").toStrings(),hist)
        }.getOrElse { fresh() }
        private fun <T> JSONArray.toModels(make:(JSONObject)->T):List<T> = (0 until length()).map { make(getJSONObject(it)) }
        private fun JSONArray.toStrings():List<String> = (0 until length()).map { getString(it) }
    }
    fun toJson():String {
        fun arr(values:List<Any>, encode:(Any)->JSONObject)=JSONArray().also { a->values.forEach { a.put(encode(it)) } }
        val o=JSONObject()
        o.put("units",arr(units){v->(v as ShadowUnit).let { JSONObject().put("id",it.id).put("name",it.name).put("role",it.role).put("rarity",it.rarity).put("level",it.level).put("evolution",it.evolution).put("ability",it.ability).put("commander",it.commander) }})
        o.put("items",arr(items){v->(v as GearItem).let { JSONObject().put("id",it.id).put("name",it.name).put("slot",it.slot).put("rarity",it.rarity).put("power",it.power).put("level",it.level).put("count",it.count).put("equipped",it.equipped) }})
        o.put("skills",arr(skills){v->(v as SkillNode).let { JSONObject().put("id",it.id).put("name",it.name).put("description",it.description).put("cost",it.cost).put("unlocked",it.unlocked) }})
        o.put("battle",JSONObject().put("active",battle.active).put("dungeon",battle.dungeon).put("dungeonName",battle.dungeonName).put("stage",battle.stage).put("playerHp",battle.playerHp).put("enemyHp",battle.enemyHp).put("enemyMaxHp",battle.enemyMaxHp).put("enemyName",battle.enemyName).put("boss",battle.boss).put("bossPhase",battle.bossPhase).put("turn",battle.turn).put("result",battle.result).put("battleId",battle.battleId))
        o.put("materials",materials).put("wins",wins).put("rankAchievements",JSONArray(rankAchievements))
        o.put("xpHistory",arr(xpHistory){v->(v as XpEntry).let { JSONObject().put("label",it.label).put("amount",it.amount).put("time",it.time) }})
        return o.toString()
    }
}

class GameProgressRepository(private val db:KiraDatabase) {
    val progress:Flow<GameSaveEntity?> = db.dao().observeGameSave()
    suspend fun initialize() { if(db.dao().getGameSave()==null) db.dao().saveGameSave(GameSaveEntity(payload=GameProgress.fresh().toJson())) }
    suspend fun update(block:(GameProgress)->GameProgress):GameProgress = db.withTransaction {
        val old=GameProgress.from(db.dao().getGameSave()?.payload)
        val next=block(old)
        db.dao().saveGameSave(GameSaveEntity(payload=next.toJson()))
        next
    }
    suspend fun trainUnit(id:String,evolve:Boolean=false) = update { g ->
        val u=g.units.firstOrNull{it.id==id} ?: return@update g
        val cost=if(evolve) 3 else 1
        if(g.materials<cost || (evolve && u.level<10)) return@update g
        g.copy(materials=g.materials-cost,units=g.units.map{if(it.id==id) it.copy(level=if(evolve) it.level else it.level+1,evolution=if(evolve) it.evolution+1 else it.evolution) else it})
    }
    suspend fun unlockSkill(id:String)=update { g -> val s=g.skills.firstOrNull{it.id==id} ?: return@update g; if(s.unlocked || g.materials<s.cost) g else g.copy(materials=g.materials-s.cost,skills=g.skills.map{if(it.id==id) it.copy(unlocked=true) else it}) }
    suspend fun equip(id:String)=update { g -> val target=g.items.firstOrNull{it.id==id} ?: return@update g; if(target.slot=="Material") g else g.copy(items=g.items.map{it.copy(equipped=if(it.slot==target.slot) it.id==id else it.equipped)}) }
    suspend fun upgradeItem(id:String)=update { g -> val target=g.items.firstOrNull{it.id==id} ?: return@update g; if(target.slot=="Material" || g.materials<2) g else g.copy(materials=g.materials-2,items=g.items.map{if(it.id==id) it.copy(level=it.level+1,power=it.power+5) else it}) }
    suspend fun craftShard()=update { g -> if(g.materials<2) g else g.copy(materials=g.materials-2,items=if(g.items.any{it.id=="shard"}) g.items.map{if(it.id=="shard") it.copy(count=it.count+1) else it} else g.items+GearItem("shard","UMBRA SHARD","Material","RARE",0,1,1,false)) }
    suspend fun startBattle(dungeon:String,name:String,stage:Int,boss:Boolean)=update { g ->
        if(g.battle.active) g else { val hp=if(boss) 190 else 70+stage*15; g.copy(battle=BattleState(true,dungeon,name,stage,if(g.skills.any{it.id=="focus"&&it.unlocked})110 else 100,hp,hp,if(boss) "GATE OVERLORD" else listOf("GATE WRAITH","ASH STALKER","VOID HOUND")[stage%3],boss,1,1,"",UUID.randomUUID().toString())) }
    }
    suspend fun playerTurn(skill:String="strike")=update { g ->
        val b=g.battle; if(!b.active) return@update g
        val sk=g.skills.firstOrNull{it.id==skill && it.unlocked} ?: g.skills.first{it.id=="strike"}
        val weapon=g.items.filter{it.equipped && it.slot!="Material"}.sumOf{it.power+it.level*2}
        val multiplier=if(g.skills.any{it.id=="sovereign"&&it.unlocked}) 1.2 else 1.0
        val damage=((if(sk.id=="echo") 24 else if(sk.id=="strike") 30 else 20)+weapon*0.45+g.units.sumOf{it.level}*0.6).times(multiplier).toInt().coerceAtLeast(1)
        val remaining=(b.enemyHp-damage).coerceAtLeast(0)
        if(remaining==0) {
            val reward=if(b.boss) 120 else 45+b.stage*10
            val next=g.copy(battle=b.copy(active=false,enemyHp=0,result="VICTORY"),wins=g.wins+1,materials=g.materials+if(b.boss) 4 else 1,xpHistory=(listOf(XpEntry("${b.dungeonName} CLEAR",reward,System.currentTimeMillis()))+g.xpHistory).take(60),items=if(b.boss) g.items.map{if(it.id=="shard") it.copy(count=it.count+2) else it} else g.items)
            next
        } else {
            val phase=if(b.boss && remaining<=b.enemyMaxHp/2) 2 else b.bossPhase
            val attack=if(b.boss) if(phase==2) 19 else 12 else 8+b.stage*2
            val hp=(b.playerHp-attack).coerceAtLeast(0)
            if(hp==0) g.copy(battle=b.copy(active=false,enemyHp=remaining,playerHp=0,bossPhase=phase,turn=b.turn+1,result="DEFEAT"))
            else g.copy(battle=b.copy(enemyHp=remaining,playerHp=hp,bossPhase=phase,turn=b.turn+1))
        }
    }
    suspend fun claimVictory()=update { g -> if(g.battle.result!="VICTORY" || g.battle.battleId.isBlank()) g else g.copy(battle=g.battle.copy(result="CLAIMED",battleId="")) }
    suspend fun retreat()=update { g -> g.copy(battle=BattleState(result="RETREATED")) }
}
