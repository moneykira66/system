package com.kira.system.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class KiraRepository(private val database: KiraDatabase) {
    private val dao = database.dao()
    val quests: Flow<List<QuestEntity>> = dao.observeQuests()
    val player: Flow<PlayerState?> = dao.observePlayer()
    val logs: Flow<List<ActivityLog>> = dao.observeLogs()
    val studyCount = dao.observeLogCount("STUDY")
    val workoutCount = dao.observeLogCount("WORKOUT")
    val studyMinutes = dao.observeLogMinutes("STUDY")
    val workoutMinutes = dao.observeLogMinutes("WORKOUT")

    suspend fun initialize() = dao.seedIfNeeded(defaultQuests())

    suspend fun createQuest(title: String, description: String, category: String, schedule: String, xp: Int) {
        require(title.isNotBlank())
        require(schedule in setOf("DAILY", "WEEKLY", "CUSTOM"))
        require(xp in 5..500)
        dao.insertQuest(QuestEntity(UUID.randomUUID().toString(), title.trim(), description.trim(), category, schedule, xp))
    }

    suspend fun completeQuest(id: String): CompletionResult = database.withTransaction {
        val quest = dao.getQuest(id) ?: return@withTransaction CompletionResult(false, 0, false)
        if (quest.archived) return@withTransaction CompletionResult(false, 0, false)
        val period = ProgressionRules.completionPeriod(quest.schedule)
        if (quest.completedPeriodKey == period) return@withTransaction CompletionResult(false, 0, false)
        dao.updateQuest(quest.copy(completedPeriodKey = period))
        val current = dao.getPlayer() ?: PlayerState()
        val progression = ProgressionRules.addXp(current.level, current.xp, current.totalXp, quest.xpReward)
        val gainedLevels = progression.levelsGained
        val updated = current.copy(
            level = progression.level,
            xp = progression.xp,
            totalXp = progression.totalXp,
            streak = if (current.lastActiveDate == ProgressionRules.dailyPeriod().removePrefix("D:")) current.streak else if (current.lastActiveDate == ProgressionRules.dailyPeriod(Date(System.currentTimeMillis() - 86_400_000L)).removePrefix("D:")) current.streak + 1 else 1,
            lastActiveDate = ProgressionRules.dailyPeriod().removePrefix("D:")
        )
        dao.savePlayer(updated)
        CompletionResult(true, quest.xpReward, gainedLevels > 0)
    }

    suspend fun addActivity(type: String, minutes: Int, note: String) = database.withTransaction {
        require(type == "STUDY" || type == "WORKOUT")
        require(minutes in 1..600)
        val awarded = maxOf(5, (minutes / 15) * 5)
        dao.insertLog(ActivityLog(UUID.randomUUID().toString(), type, minutes, note.trim(), xpAwarded = awarded))
        val current = dao.getPlayer() ?: PlayerState()
        val progression = ProgressionRules.addXp(current.level, current.xp, current.totalXp, awarded)
        dao.savePlayer(current.copy(level = progression.level, xp = progression.xp, totalXp = progression.totalXp))
    }

    suspend fun updateSettings(name: String, sound: Boolean, haptics: Boolean) {
        val current = dao.getPlayer() ?: PlayerState()
        dao.savePlayer(current.copy(displayName = name.trim().ifBlank { "SHADOW WALKER" }, soundEnabled = sound, hapticsEnabled = haptics))
    }

    private fun defaultQuests() = listOf(
        QuestEntity("seed-move", "MOVE YOUR BODY", "20 minutes of movement or training", "WORKOUT", "DAILY", 40),
        QuestEntity("seed-study", "DEEP WORK SESSION", "Study, code, or practice for 25 minutes", "STUDY", "DAILY", 50),
        QuestEntity("seed-water", "HYDRATION PROTOCOL", "Drink water consistently today", "VITALS", "DAILY", 20),
        QuestEntity("seed-read", "KNOWLEDGE ABSORPTION", "Read 10 pages or review your notes", "STUDY", "DAILY", 30),
        QuestEntity("seed-recovery", "RECOVERY MODE", "Protect your sleep and recovery", "VITALS", "DAILY", 35),
        QuestEntity("seed-weekly", "WEEKLY ASCENSION", "Complete a meaningful weekly milestone", "MIND", "WEEKLY", 120)
    )

    companion object { const val XP_PER_LEVEL = ProgressionRules.XP_PER_LEVEL }
}

data class CompletionResult(val accepted: Boolean, val xp: Int, val levelUp: Boolean)
