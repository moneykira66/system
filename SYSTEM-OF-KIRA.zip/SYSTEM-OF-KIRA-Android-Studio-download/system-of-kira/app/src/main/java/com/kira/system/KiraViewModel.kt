package com.kira.system

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kira.system.data.KiraDatabase
import com.kira.system.data.KiraRepository
import com.kira.system.data.GameProgress
import com.kira.system.data.GameProgressRepository
import com.kira.system.data.QuestEntity
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class KiraViewModel(application: Application) : AndroidViewModel(application) {
    private val database = KiraDatabase.get(application)
    private val repository = KiraRepository(database)
    private val gameRepository = GameProgressRepository(database)
    val game = gameRepository.progress.map { GameProgress.from(it?.payload) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GameProgress.fresh())
    val quests = repository.quests.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val player = repository.player.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val logs = repository.logs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val studyCount = repository.studyCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val workoutCount = repository.workoutCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val studyMinutes = repository.studyMinutes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val workoutMinutes = repository.workoutMinutes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    init { viewModelScope.launch { repository.initialize(); gameRepository.initialize() } }
    fun completeQuest(id: String, onResult: (Boolean, Boolean) -> Unit = { _, _ -> }) = viewModelScope.launch {
        val result = runCatching { repository.completeQuest(id) }.getOrNull()
        onResult(result?.accepted == true, result?.levelUp == true)
    }
    fun createQuest(title: String, description: String, category: String, schedule: String, xp: Int, onDone: (Boolean) -> Unit) = viewModelScope.launch {
        val result = runCatching { repository.createQuest(title, description, category, schedule, xp) }.isSuccess
        onDone(result)
    }
    fun addLog(type: String, minutes: Int, note: String, onDone: (Boolean) -> Unit) = viewModelScope.launch {
        onDone(runCatching { repository.addActivity(type, minutes, note) }.isSuccess)
    }
    fun saveSettings(name: String, sound: Boolean, haptics: Boolean) = viewModelScope.launch { repository.updateSettings(name, sound, haptics) }
    fun isDone(quest: QuestEntity, now: java.util.Date = java.util.Date()): Boolean {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(now)
        val week = java.util.Calendar.getInstance().apply { time = now; firstDayOfWeek = java.util.Calendar.MONDAY; minimalDaysInFirstWeek = 4 }
        val period = "%04d-W%02d".format(java.util.Locale.US, week.getWeekYear(), week.get(java.util.Calendar.WEEK_OF_YEAR))
        return when (quest.schedule) {
            "DAILY" -> quest.completedPeriodKey == "D:$today"
            "WEEKLY" -> quest.completedPeriodKey == "W:$period"
            else -> quest.completedPeriodKey == "CUSTOM:ONCE"
        }
    }

    fun trainUnit(id: String, evolve: Boolean = false) = viewModelScope.launch { gameRepository.trainUnit(id, evolve) }
    fun unlockSkill(id: String) = viewModelScope.launch { gameRepository.unlockSkill(id) }
    fun equipItem(id: String) = viewModelScope.launch { gameRepository.equip(id) }
    fun upgradeItem(id: String) = viewModelScope.launch { gameRepository.upgradeItem(id) }
    fun craftShard() = viewModelScope.launch { gameRepository.craftShard() }
    fun startBattle(id: String, name: String, stage: Int, boss: Boolean) = viewModelScope.launch { gameRepository.startBattle(id, name, stage, boss) }
    fun battleTurn(skill: String) = viewModelScope.launch { gameRepository.playerTurn(skill) }
    fun claimVictory() = viewModelScope.launch { gameRepository.claimVictory() }
    fun retreatBattle() = viewModelScope.launch { gameRepository.retreat() }

}
