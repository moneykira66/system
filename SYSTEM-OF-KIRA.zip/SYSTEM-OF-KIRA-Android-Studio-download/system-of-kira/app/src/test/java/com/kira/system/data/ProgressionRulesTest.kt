package com.kira.system.data

import org.junit.Assert.assertEquals
import org.junit.Test

class ProgressionRulesTest {
    @Test fun xpCarriesAcrossLevelsAndTracksLifetimeTotal() {
        val result = ProgressionRules.addXp(level = 2, xp = 190, totalXp = 590, awarded = 35)
        assertEquals(3, result.level)
        assertEquals(25, result.xp)
        assertEquals(625L, result.totalXp)
        assertEquals(1, result.levelsGained)
    }

    @Test fun ranksFollowEToSThresholds() {
        assertEquals("E", ProgressionRules.rankForLevel(1))
        assertEquals("D", ProgressionRules.rankForLevel(7))
        assertEquals("C", ProgressionRules.rankForLevel(15))
        assertEquals("B", ProgressionRules.rankForLevel(25))
        assertEquals("A", ProgressionRules.rankForLevel(35))
        assertEquals("S", ProgressionRules.rankForLevel(50))
    }

    @Test fun customQuestPeriodIsOneTime() {
        assertEquals("CUSTOM:ONCE", ProgressionRules.completionPeriod("CUSTOM"))
    }
}
